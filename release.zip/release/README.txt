PropertyManager — Server Setup
==============================

REQUIREMENTS
------------
- Node.js 18 or newer (https://nodejs.org)

FIRST-TIME SETUP
----------------
1. Copy this entire 'release' folder to your server.

2. Open a terminal in the 'server' folder and install dependencies:
     npm install

3. (Optional) Edit server/.env to change the port or generate a new JWT secret:
     PORT=3001
     HOST=0.0.0.0
     JWT_SECRET=<change this to a long random string for production>
     JWT_EXPIRES_IN=7d

STARTING THE SERVER
-------------------
From the 'server' folder, run:
     node index.js

The app will be available at:
  - Local:  http://localhost:3001
  - LAN:    http://<your-server-ip>:3001

The server automatically serves the built web app from client/dist.
Uploaded photos are stored in the 'uploads' folder (auto-created).
The database file is stored in the 'data' folder (auto-created).

NETWORK ACCESS (WSL2 ON WINDOWS)
---------------------------------
If the server runs inside WSL2 (Ubuntu on Windows), other LAN devices cannot
reach it directly — WSL2 uses a virtual NAT, not a bridged adapter. You must
add a port proxy and a firewall rule on the Windows host.

1. Find the WSL IP (run in the Ubuntu terminal):
     hostname -I
   Take the first address shown (e.g. 172.x.x.x).

2. Find the Windows host IP (run in Windows CMD):
     ipconfig
   Look for the LAN adapter "IPv4 Address" (e.g. 192.168.x.x).
   This is the address LAN devices will connect to.

3. Open PowerShell as Administrator and run both commands:

   a. Port proxy — forwards Windows port 3001 → WSL port 3001:
        netsh interface portproxy add v4tov4 listenport=3001 listenaddress=0.0.0.0 connectport=3001 connectaddress=<WSL_IP>
      (replace <WSL_IP> with the address from step 1)

   b. Firewall rule — allows inbound TCP on port 3001 (only needed once):
        New-NetFireWallRule -DisplayName "PropertyManager" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 3001

4. After every reboot — the WSL IP changes, so re-run the portproxy command
   with the new IP (the firewall rule persists). One-liner that auto-detects
   the current WSL IP — paste into an elevated PowerShell:
     $wslIp = (wsl hostname -I).Trim().Split(' ')[0]; netsh interface portproxy add v4tov4 listenport=3001 listenaddress=0.0.0.0 connectport=3001 connectaddress=$wslIp

5. Verify — from another device on the LAN, open:
     http://<Windows-host-IP>:3001

6. To remove the port proxy if no longer needed (elevated PowerShell):
     netsh interface portproxy delete v4tov4 listenport=3001 listenaddress=0.0.0.0

KEEPING IT RUNNING (optional)
------------------------------
To keep the server running after closing the terminal, use pm2:
     npm install -g pm2
     pm2 start index.js --name property-manager
     pm2 save
     pm2 startup

FOLDER STRUCTURE
----------------
release/
  server/         <- Express API server
  client/dist/    <- Built web app (served by the server)
  README.txt      <- This file

Data folders created automatically on first run:
  data/app.db     <- SQLite database
  uploads/        <- Uploaded photos
