const express = require('express');
const path = require('path');
const fs = require('fs');
const nodemailer = require('nodemailer');
const db = require('../db');
const auth = require('../middleware/auth');

const router = express.Router();
const uploadsDir = path.join(__dirname, '..', '..', 'uploads');
const ALLOWED_TAGS = ['lead', 'bid', 'in_progress', 'done'];

// All routes require auth
router.use(auth);

// GET /api/projects?search=
router.get('/', (req, res) => {
  const { search } = req.query;
  let rows;
  if (search) {
    rows = db
      .prepare(`SELECT * FROM projects WHERE name LIKE ? ORDER BY updated_at DESC`)
      .all(`%${search}%`);
  } else {
    rows = db
      .prepare(`SELECT * FROM projects ORDER BY updated_at DESC`)
      .all();
  }
  res.json(rows);
});

// POST /api/projects
router.post('/', (req, res) => {
  const { name, description, lat, lng, address, tag, email, phone } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Project name is required' });
  }
  const tagValue = tag && ALLOWED_TAGS.includes(tag) ? tag : 'lead';
  const emailVal = email && typeof email === 'string' ? email.trim() || null : null;
  const phoneVal = phone && typeof phone === 'string' ? phone.trim() || null : null;
  const result = db
    .prepare(`INSERT INTO projects (user_id, name, description, lat, lng, address, tag, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(req.user.id, name.trim(), description || null, lat ?? null, lng ?? null, address || null, tagValue, emailVal, phoneVal);
  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(project);
});

// POST /api/projects/:id/export-email (must be before GET /:id)
router.post('/:id/export-email', async (req, res) => {
  const project = db
    .prepare('SELECT * FROM projects WHERE id = ?')
    .get(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const to = req.body.to && String(req.body.to).trim();
  if (!to || to.length < 5) {
    return res.status(400).json({ error: 'Valid recipient email is required' });
  }
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(to)) {
    return res.status(400).json({ error: 'Valid recipient email is required' });
  }

  const { SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS } = process.env;
  if (!SMTP_HOST || !SMTP_PORT || !SMTP_USER || !SMTP_PASS) {
    return res.status(503).json({ error: 'Email is not configured. Set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS in server/.env' });
  }

  const notes = db
    .prepare('SELECT * FROM notes WHERE project_id = ? ORDER BY created_at ASC')
    .all(req.params.id);
  const photos = db
    .prepare('SELECT * FROM photos WHERE project_id = ? ORDER BY uploaded_at ASC')
    .all(req.params.id);

  const lines = [
    `Project: ${project.name || '(no name)'}`,
    '',
    project.description ? `Description: ${project.description}` : '',
    project.address ? `Address: ${project.address}` : '',
    project.email ? `Contact email: ${project.email}` : '',
    project.phone ? `Contact phone: ${project.phone}` : '',
    '',
    '--- Notes ---',
    ...(notes.length
      ? notes.map((n) => `[${n.created_at}] ${(n.body || '').replace(/\n/g, ' ')}`)
      : ['(no notes)']),
    '',
    photos.length ? `--- ${photos.length} photo(s) attached ---` : '',
  ].filter(Boolean);

  const textBody = lines.join('\n');
  const attachments = [];
  for (const photo of photos) {
    const filePath = path.join(uploadsDir, photo.filename);
    if (fs.existsSync(filePath)) {
      attachments.push({
        filename: photo.original_name || photo.filename,
        content: fs.readFileSync(filePath),
        contentType: photo.mimetype || undefined,
      });
    }
  }

  try {
    const transport = nodemailer.createTransport({
      host: SMTP_HOST,
      port: Number(SMTP_PORT) || 587,
      secure: SMTP_SECURE === 'true',
      auth: { user: SMTP_USER, pass: SMTP_PASS },
    });
    await transport.sendMail({
      from: process.env.MAIL_FROM || SMTP_USER,
      to,
      subject: `Project export: ${project.name || 'Untitled'}`,
      text: textBody,
      attachments,
    });
    res.json({ success: true });
  } catch (err) {
    console.error('Export email error:', err.message);
    res.status(500).json({ error: 'Failed to send email. Check SMTP settings.' });
  }
});

// GET /api/projects/:id
router.get('/:id', (req, res) => {
  const project = db
    .prepare('SELECT * FROM projects WHERE id = ?')
    .get(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  res.json(project);
});

// PATCH /api/projects/:id
router.patch('/:id', (req, res) => {
  const project = db
    .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const { name, description, lat, lng, address, tag, email, phone } = req.body;
  const currentTag = project.tag ?? 'lead';
  const tagValue = tag !== undefined
    ? (ALLOWED_TAGS.includes(tag) ? tag : currentTag)
    : currentTag;
  const emailVal = email !== undefined ? (email && typeof email === 'string' ? email.trim() || null : project.email) : project.email;
  const phoneVal = phone !== undefined ? (phone && typeof phone === 'string' ? phone.trim() || null : project.phone) : project.phone;
  db
    .prepare(`
      UPDATE projects
      SET name = ?, description = ?, lat = ?, lng = ?, address = ?, tag = ?, email = ?, phone = ?, updated_at = datetime('now')
      WHERE id = ? AND user_id = ?
    `)
    .run(
      name !== undefined ? name.trim() : project.name,
      description !== undefined ? description : project.description,
      lat !== undefined ? lat : project.lat,
      lng !== undefined ? lng : project.lng,
      address !== undefined ? address : project.address,
      tagValue,
      emailVal,
      phoneVal,
      req.params.id,
      req.user.id
    );

  const result = db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id);
  res.json(result);
});

// DELETE /api/projects/:id
router.delete('/:id', (req, res) => {
  const project = db
    .prepare('SELECT id FROM projects WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  db.prepare('DELETE FROM projects WHERE id = ?').run(req.params.id);
  res.status(204).send();
});

module.exports = router;
